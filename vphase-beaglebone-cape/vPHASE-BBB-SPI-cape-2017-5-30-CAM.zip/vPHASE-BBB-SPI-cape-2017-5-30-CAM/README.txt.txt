vPHASE-BBB-SPI-cape-2017-5-30-CAM
----
4-layer board
1.6mm stackup height
Board dimension 80.6 mm x 54.6 mm (3.175" x 2.150")
----
Top layer : EtchLayer1Top.gdo
2nd layer [negative plane]: EtchLayer2Neg.gdo
3rd layer [negative plane]: EtchLayer3Neg.gdo
Bottom layer : EtchLayer4Bottom.gdo

Soldermask on both sides

Silkscreen on top side only